<footer class="site-footer">
  <div class="container footer-inner">
    <div>
      <a class="brand" href="<?php echo esc_url(home_url('/')); ?>"><span class="brand-mark">C</span><span>Cometa Conecta</span></a>
      <p>Entretenimento conectado ao seu jeito.</p>
      <small>© <?php echo esc_html(wp_date('Y')); ?> Cometa Conecta. Todos os direitos reservados.</small>
    </div>
    <nav class="footer-links" aria-label="Menu do rodapé">
      <?php wp_nav_menu(array('theme_location' => 'footer', 'container' => false, 'depth' => 1, 'items_wrap' => '%3$s', 'fallback_cb' => false)); ?>
      <a href="<?php echo esc_url(home_url('/politica-de-privacidade/')); ?>">Privacidade</a>
    </nav>
  </div>
</footer>
<a class="whatsapp-float" href="<?php echo esc_url(cometa_conecta_whatsapp_url()); ?>" target="_blank" rel="noopener noreferrer" aria-label="Fale com a Cometa Conecta pelo WhatsApp" title="Fale conosco no WhatsApp">☏</a>
<?php wp_footer(); ?>
</body>
</html>
