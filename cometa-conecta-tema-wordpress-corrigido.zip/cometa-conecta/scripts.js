document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-navigation');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      const isOpen = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.matchMedia('(max-width: 900px)').matches) {
          nav.classList.remove('is-open');
          toggle.setAttribute('aria-expanded', 'false');
        }
      });
    });
  }

  if (typeof Swiper !== 'undefined') {
    document.querySelectorAll('[data-cometa-slider]').forEach(function (slider) {
      const shell = slider.closest('.slider-shell');
      new Swiper(slider, {
        slidesPerView: 1.25,
        spaceBetween: 14,
        speed: 450,
        watchOverflow: true,
        navigation: {
          nextEl: shell ? shell.querySelector('.slider-next') : null,
          prevEl: shell ? shell.querySelector('.slider-prev') : null
        },
        breakpoints: {
          480: { slidesPerView: 2.1, spaceBetween: 16 },
          720: { slidesPerView: 3.1, spaceBetween: 18 },
          1024: { slidesPerView: 4.1, spaceBetween: 20 }
        }
      });
    });
  }
});
