<?php
/**
 * Funções do tema Cometa Conecta.
 */
if (!defined('ABSPATH')) { exit; }

function cometa_conecta_setup() {
    load_theme_textdomain('cometa-conecta', get_template_directory() . '/languages');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array('height' => 80, 'width' => 240, 'flex-height' => true, 'flex-width' => true));
    register_nav_menus(array('primary' => __('Menu principal', 'cometa-conecta'), 'footer' => __('Menu do rodapé', 'cometa-conecta')));
}
add_action('after_setup_theme', 'cometa_conecta_setup');

function cometa_conecta_assets() {
    wp_enqueue_style('cometa-conecta-style', get_stylesheet_uri(), array(), '1.0.0');
    wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.1.4');
    wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.1.4', true);
    wp_enqueue_script('cometa-conecta-scripts', get_template_directory_uri() . '/scripts.js', array('swiper-js'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'cometa_conecta_assets');

/** Planos editáveis no painel: Planos > Adicionar novo. */
function cometa_conecta_register_plan_cpt() {
    register_post_type('cc_plan', array(
        'labels' => array(
            'name' => __('Planos', 'cometa-conecta'),
            'singular_name' => __('Plano', 'cometa-conecta'),
            'add_new_item' => __('Adicionar plano', 'cometa-conecta'),
            'edit_item' => __('Editar plano', 'cometa-conecta'),
        ),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-tickets-alt',
        'supports' => array('title', 'editor', 'page-attributes', 'thumbnail'),
        'has_archive' => false,
    ));
}
add_action('init', 'cometa_conecta_register_plan_cpt');

function cometa_conecta_plan_meta_boxes() {
    add_meta_box('cc_plan_details', __('Detalhes do plano', 'cometa-conecta'), 'cometa_conecta_plan_meta_box_html', 'cc_plan', 'normal', 'high');
}
add_action('add_meta_boxes', 'cometa_conecta_plan_meta_boxes');

function cometa_conecta_plan_meta_box_html($post) {
    wp_nonce_field('cc_plan_save', 'cc_plan_nonce');
    $fields = array(
        'price' => __('Preço (ex.: 39,90)', 'cometa-conecta'),
        'period' => __('Período (ex.: /mês)', 'cometa-conecta'),
        'kind' => __('Categoria (IPTV, P2P ou outro)', 'cometa-conecta'),
        'features' => __('Benefícios (um por linha)', 'cometa-conecta'),
        'badge' => __('Selo opcional (ex.: Mais vendido)', 'cometa-conecta'),
        'featured' => __('Destacar este plano? Digite sim ou não', 'cometa-conecta'),
        'button' => __('Texto do botão', 'cometa-conecta'),
    );
    foreach ($fields as $key => $label) {
        $value = get_post_meta($post->ID, '_cc_' . $key, true);
        echo '<p><label for="cc_' . esc_attr($key) . '"><strong>' . esc_html($label) . '</strong></label><br>';
        if ($key === 'features') {
            echo '<textarea style="width:100%;min-height:100px" id="cc_' . esc_attr($key) . '" name="cc_' . esc_attr($key) . '">' . esc_textarea($value) . '</textarea>';
        } else {
            echo '<input style="width:100%" id="cc_' . esc_attr($key) . '" name="cc_' . esc_attr($key) . '" value="' . esc_attr($value) . '" type="text">';
        }
        echo '</p>';
    }
    echo '<p class="description">O conteúdo do editor do plano aparece como descrição. O preço e os benefícios são configurados acima.</p>';
}

function cometa_conecta_save_plan_meta($post_id) {
    if (!isset($_POST['cc_plan_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['cc_plan_nonce'])), 'cc_plan_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;
    $keys = array('price', 'period', 'kind', 'features', 'badge', 'featured', 'button');
    foreach ($keys as $key) {
        if (!isset($_POST['cc_' . $key])) continue;
        $raw = wp_unslash($_POST['cc_' . $key]);
        $value = $key === 'features' ? sanitize_textarea_field($raw) : sanitize_text_field($raw);
        update_post_meta($post_id, '_cc_' . $key, $value);
    }
}
add_action('save_post_cc_plan', 'cometa_conecta_save_plan_meta');

/** Conteúdo editável do hero e WhatsApp em Aparência > Personalizar. */
function cometa_conecta_customize_register($wp_customize) {
    $wp_customize->add_section('cc_home_section', array('title' => __('Cometa Conecta — Página inicial', 'cometa-conecta'), 'priority' => 30));
    $settings = array(
        'cc_hero_kicker' => array('label' => 'Texto pequeno do destaque', 'default' => 'ENTRETENIMENTO DO SEU JEITO'),
        'cc_hero_title' => array('label' => 'Título principal', 'default' => 'Seu próximo universo de entretenimento começa aqui.'),
        'cc_hero_text' => array('label' => 'Descrição principal', 'default' => 'Conheça nossos planos e fale com a equipe Cometa Conecta para encontrar a opção ideal para você.'),
        'cc_whatsapp_message' => array('label' => 'Mensagem padrão do WhatsApp', 'default' => 'Olá! Quero saber mais sobre os planos Cometa Conecta.'),
        'cc_members_url' => array('label' => 'URL da Área de Membros', 'default' => '/wp-login.php'),
    );
    foreach ($settings as $id => $item) {
        $wp_customize->add_setting($id, array('default' => $item['default'], 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'refresh'));
        $wp_customize->add_control($id, array('label' => $item['label'], 'section' => 'cc_home_section', 'type' => 'text'));
    }
}
add_action('customize_register', 'cometa_conecta_customize_register');

function cometa_conecta_whatsapp_url($message = '') {
    $default = get_theme_mod('cc_whatsapp_message', 'Olá! Quero saber mais sobre os planos Cometa Conecta.');
    $message = $message !== '' ? $message : $default;
    return 'https://wa.me/5541997828563?text=' . rawurlencode($message);
}
function cometa_conecta_whatsapp_link($message = '', $label = 'Fale pelo WhatsApp', $class = 'btn btn-whatsapp') {
    return '<a class="' . esc_attr($class) . '" href="' . esc_url(cometa_conecta_whatsapp_url($message)) . '" target="_blank" rel="noopener noreferrer">' . esc_html($label) . '</a>';
}

/** Itens demonstrativos dos carrosséis; personalize em Aparência > Personalizar ou substitua os cards no template. */
function cometa_conecta_demo_media() {
    return array(
        array(
            'title' => 'Filmes em destaque',
            'subtitle' => 'Descubra sua próxima sessão',
            'image' => 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&w=900&q=85',
            'alt' => 'Sala de cinema com poltronas'
        ),
        array(
            'title' => 'Séries para maratonar',
            'subtitle' => 'Histórias para todos os momentos',
            'image' => 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?auto=format&fit=crop&w=900&q=85',
            'alt' => 'Pessoa assistindo a uma tela de televisão'
        ),
        array(
            'title' => 'Canais ao vivo',
            'subtitle' => 'Conteúdo em tempo real',
            'image' => 'https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&w=900&q=85',
            'alt' => 'Televisão em uma sala moderna'
        ),
        array(
            'title' => 'Esportes e eventos',
            'subtitle' => 'Acompanhe o que importa',
            'image' => 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=900&q=85',
            'alt' => 'Atletas competindo em uma pista esportiva'
        ),
        array(
            'title' => 'Conteúdo para a família',
            'subtitle' => 'Opções para compartilhar',
            'image' => 'https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=900&q=85',
            'alt' => 'Família reunida ao ar livre'
        ),
    );
}
