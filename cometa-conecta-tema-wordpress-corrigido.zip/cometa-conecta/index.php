<?php get_header(); ?>
<main id="main-content">
<?php if (is_front_page() || is_home()) : ?>
  <section class="hero">
    <div class="container hero-content">
      <span class="eyebrow"><?php echo esc_html(get_theme_mod('cc_hero_kicker', 'ENTRETENIMENTO DO SEU JEITO')); ?></span>
      <h1><?php echo esc_html(get_theme_mod('cc_hero_title', 'Seu próximo universo de entretenimento começa aqui.')); ?></h1>
      <p><?php echo esc_html(get_theme_mod('cc_hero_text', 'Conheça nossos planos e fale com a equipe Cometa Conecta para encontrar a opção ideal para você.')); ?></p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="#planos">Conhecer os planos <span aria-hidden="true">→</span></a>
        <?php echo cometa_conecta_whatsapp_link('Olá! Quero conhecer os planos da Cometa Conecta.', 'Falar com um especialista'); ?>
      </div>
    </div>
  </section>

  <section class="section" aria-labelledby="catalogo-title">
    <div class="container">
      <div class="section-heading"><div><span class="eyebrow">Explore possibilidades</span><h2 id="catalogo-title">Um mundo de entretenimento</h2><p>Uma vitrine visual para apresentar categorias e destaques do seu catálogo autorizado.</p></div></div>
      <div class="slider-shell">
        <button class="slider-arrow slider-prev" type="button" aria-label="Itens anteriores">‹</button>
        <div class="swiper content-slider" data-cometa-slider>
          <div class="swiper-wrapper">
            <?php foreach (cometa_conecta_demo_media() as $item) : ?>
              <div class="swiper-slide">
                <article class="media-card">
                  <img src="<?php echo esc_url($item['image']); ?>" alt="<?php echo esc_attr($item['alt']); ?>" loading="lazy" decoding="async">
                  <div class="media-card-caption"><h3><?php echo esc_html($item['title']); ?></h3><p><?php echo esc_html($item['subtitle']); ?></p></div>
                </article>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
        <button class="slider-arrow slider-next" type="button" aria-label="Próximos itens">›</button>
      </div>
    </div>
  </section>

  <section class="section" id="planos" aria-labelledby="planos-title">
    <div class="container">
      <div class="section-heading"><div><span class="eyebrow">Escolha o seu plano</span><h2 id="planos-title">Planos Cometa Conecta</h2><p>Planos e preços podem ser atualizados no painel do WordPress.</p></div></div>
      <div class="plans-grid">
      <?php
      $plans = new WP_Query(array('post_type' => 'cc_plan', 'post_status' => 'publish', 'posts_per_page' => 12, 'orderby' => array('menu_order' => 'ASC', 'date' => 'DESC')));
      if ($plans->have_posts()) :
        while ($plans->have_posts()) : $plans->the_post();
          $price = get_post_meta(get_the_ID(), '_cc_price', true);
          $period = get_post_meta(get_the_ID(), '_cc_period', true);
          $kind = get_post_meta(get_the_ID(), '_cc_kind', true);
          $features = get_post_meta(get_the_ID(), '_cc_features', true);
          $badge = get_post_meta(get_the_ID(), '_cc_badge', true);
          $featured = strtolower(get_post_meta(get_the_ID(), '_cc_featured', true)) === 'sim';
          $button = get_post_meta(get_the_ID(), '_cc_button', true) ?: 'Contratar pelo WhatsApp';
          $message = 'Olá! Tenho interesse no plano ' . get_the_title() . ($kind ? ' (' . $kind . ')' : '') . '. Poderia me passar mais informações?';
      ?>
        <article class="plan-card <?php echo $featured ? 'featured' : ''; ?>">
          <?php if ($badge) : ?><span class="plan-badge"><?php echo esc_html($badge); ?></span><?php endif; ?>
          <span class="plan-type"><?php echo esc_html($kind ?: 'Plano Cometa'); ?></span>
          <h3><?php the_title(); ?></h3>
          <div class="plan-price"><?php echo $price !== '' ? esc_html($price) : 'Consulte'; ?><?php if ($period) : ?><small><?php echo esc_html($period); ?></small><?php endif; ?></div>
          <p class="plan-description"><?php echo esc_html(wp_trim_words(get_the_excerpt() ?: wp_strip_all_tags(get_the_content()), 22)); ?></p>
          <span class="pix-badge" aria-label="Pagamento via PIX">◇ PIX · pagamento facilitado</span>
          <?php if ($features) : ?><ul class="plan-features"><?php foreach (preg_split('/\r\n|\r|\n/', $features) as $feature) : if (trim($feature) !== '') : ?><li><?php echo esc_html(trim($feature)); ?></li><?php endif; endforeach; ?></ul><?php endif; ?>
          <?php echo cometa_conecta_whatsapp_link($message, $button, 'btn btn-whatsapp'); ?>
        </article>
      <?php
        endwhile;
        wp_reset_postdata();
      else :
        $demo_plans = array(
          array('kind'=>'IPTV', 'title'=>'Plano Essencial', 'price'=>'Consulte', 'desc'=>'Uma opção para começar. Configure seus benefícios no painel.', 'features'=>array('Atendimento pelo WhatsApp','Orientação para configuração')),
          array('kind'=>'P2P', 'title'=>'Plano Conecta', 'price'=>'Consulte', 'desc'=>'Uma opção intermediária para conhecer o serviço.', 'features'=>array('Suporte ao cliente','Ajuda na ativação')),
          array('kind'=>'IPTV / P2P', 'title'=>'Plano Premium', 'price'=>'Consulte', 'desc'=>'Uma opção em destaque. Configure os detalhes no painel.', 'features'=>array('Atendimento prioritário','Orientação de uso')),
        );
        foreach ($demo_plans as $p) :
          $message = 'Olá! Tenho interesse no ' . $p['title'] . ' (' . $p['kind'] . '). Poderia me passar valores e condições?';
      ?>
        <article class="plan-card <?php echo $p['title'] === 'Plano Premium' ? 'featured' : ''; ?>">
          <?php if ($p['title'] === 'Plano Premium') : ?><span class="plan-badge">Em destaque</span><?php endif; ?>
          <span class="plan-type"><?php echo esc_html($p['kind']); ?></span><h3><?php echo esc_html($p['title']); ?></h3>
          <div class="plan-price"><?php echo esc_html($p['price']); ?></div><p class="plan-description"><?php echo esc_html($p['desc']); ?></p>
          <span class="pix-badge">◇ PIX · pagamento facilitado</span><ul class="plan-features"><?php foreach ($p['features'] as $feature) : ?><li><?php echo esc_html($feature); ?></li><?php endforeach; ?></ul>
          <?php echo cometa_conecta_whatsapp_link($message, 'Consultar pelo WhatsApp', 'btn btn-whatsapp'); ?>
        </article>
      <?php endforeach; endif; ?>
      </div>
      <p style="color:var(--cc-muted);font-size:.85rem;margin-top:18px">Valores, disponibilidade, compatibilidade e condições de pagamento devem ser confirmados com a equipe antes da contratação.</p>
    </div>
  </section>

  <section class="section">
    <div class="container">
      <div class="section-heading"><div><span class="eyebrow">Por que Cometa?</span><h2>Atendimento simples, do início ao fim</h2></div></div>
      <div class="benefits-grid">
        <article class="benefit"><span class="icon">⚡</span><h3>Atendimento rápido</h3><p>Tire dúvidas e receba orientações diretamente pelo WhatsApp.</p></article>
        <article class="benefit"><span class="icon">◇</span><h3>PIX facilitado</h3><p>Consulte as condições de pagamento disponíveis para cada plano.</p></article>
        <article class="benefit"><span class="icon">▣</span><h3>Ajuda na configuração</h3><p>Receba instruções de uso e compatibilidade para dispositivos suportados.</p></article>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="container"><div class="cta-band"><div><h2>Vamos encontrar o plano ideal para você?</h2><p>Fale com a Cometa Conecta e tire suas dúvidas antes de contratar.</p></div><?php echo cometa_conecta_whatsapp_link('Olá! Quero ajuda para escolher um plano Cometa Conecta.', 'Conversar agora'); ?></div></div>
  </section>
<?php else : ?>
  <section class="page-content"><div class="container">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
        <h1 class="entry-title"><?php the_title(); ?></h1>
        <div class="entry-content"><?php the_content(); ?></div>
      </article>
    <?php endwhile; the_posts_pagination(); else : ?>
      <h1>Nenhum conteúdo encontrado</h1><p>Adicione páginas e posts no painel do WordPress.</p>
    <?php endif; ?>
  </div></section>
<?php endif; ?>
</main>
<?php get_footer(); ?>
