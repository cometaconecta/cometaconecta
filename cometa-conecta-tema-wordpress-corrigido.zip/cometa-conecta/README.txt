COMETA CONECTA — TEMA WORDPRESS
================================

Arquivos principais:
- style.css
- functions.php
- index.php
- header.php
- footer.php
- scripts.js

INSTALAÇÃO
1. Envie a pasta "cometa-conecta" para wp-content/themes/ do WordPress.
2. No painel, vá a Aparência > Temas e ative "Cometa Conecta".
3. Em Aparência > Menus, crie um menu e atribua a "Menu principal". Para o rodapé, atribua outro menu a "Menu do rodapé".
4. Em Aparência > Personalizar > Cometa Conecta — Página inicial, edite título, texto, mensagem do WhatsApp e destino da Área de Membros.
5. No painel, abra Planos e adicione seus planos. Preencha preço, período, categoria, benefícios (um por linha), selo e destaque.
6. Configure a página inicial em Configurações > Leitura, se necessário.

WHATSAPP
O tema usa o número configurado no requisito: +55 41 99782-8563
Formato: https://wa.me/5541997828563?text=...
A mensagem padrão pode ser editada no Personalizar. Os botões de planos enviam o nome do plano na mensagem.

CARROSSEL
Swiper.js é carregado por CDN. As cinco categorias iniciais já exibem imagens temáticas carregadas do Unsplash. Elas são imagens ilustrativas e não representam um catálogo real. Para usar suas próprias imagens, substitua os endereços definidos na função cometa_conecta_demo_media(), em functions.php, por URLs de imagens da sua Biblioteca de mídia do WordPress.

ÁREA DE MEMBROS
Por padrão, o botão aponta para /wp-login.php. Você pode trocar a URL em Personalizar. O WordPress gerencia usuários e senhas. Para área de membros restrita com páginas protegidas, use um plugin de membership ou implemente regras de acesso adequadas.

NOTAS IMPORTANTES
- O tema é uma base funcional, não inclui gateway de pagamento, cobrança recorrente, painel de assinantes nem autenticação de streaming.
- O selo PIX é visual e informativo; não processa pagamentos. Integre um provedor/gateway confiável se quiser receber pagamentos no site.
- Use apenas conteúdos e serviços para os quais você tenha direitos de distribuição/licenciamento e apresente termos, política de privacidade e condições de assinatura antes da contratação.
- Antes de publicar, teste em staging, faça backup e revise acessibilidade, segurança, SEO e desempenho.
