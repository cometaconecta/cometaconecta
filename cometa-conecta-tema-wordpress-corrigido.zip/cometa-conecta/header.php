<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
  <div class="container header-inner">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
      <?php if (has_custom_logo()) { the_custom_logo(); } else { ?><span class="brand-mark">C</span><span>Cometa Conecta</span><?php } ?>
    </a>
    <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-navigation">☰ <span class="screen-reader-text">Abrir menu</span></button>
    <nav id="primary-navigation" class="primary-nav" aria-label="Menu principal">
      <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'depth' => 3)); ?>
    </nav>
    <div class="header-actions">
      <a class="btn btn-primary" href="<?php echo esc_url(get_theme_mod('cc_members_url', home_url('/wp-login.php'))); ?>">Área de Membros</a>
    </div>
  </div>
</header>
